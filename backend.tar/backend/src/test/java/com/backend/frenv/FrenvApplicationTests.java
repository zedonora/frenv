package com.backend.frenv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 빌드 오류로 인한 임시 주석 처리
 */
//@SpringBootTest
//class FrenvApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}

//}
