package com.backend.frenv.domain.user.entity.enums;

public enum Gender {
    MAN, WOMAN
}
