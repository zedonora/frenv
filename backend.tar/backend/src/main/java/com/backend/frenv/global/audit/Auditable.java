package com.backend.frenv.global.audit;

public interface Auditable {
    TimeEntity getTimeEntity();
    void setTimeEntity(TimeEntity timeEntity);
}
