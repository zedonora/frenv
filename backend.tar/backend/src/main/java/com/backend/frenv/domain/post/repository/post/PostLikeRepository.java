package com.backend.frenv.domain.post.repository.post;

import com.backend.frenv.domain.post.entity.Post;
import com.backend.frenv.domain.post.entity.PostLike;
import com.backend.frenv.domain.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PostLikeRepository extends JpaRepository<PostLike, Long> {
    Optional<PostLike> findByUserAndPost(User user, Post post);

}
