package com.backend.frenv.domain.asset.entity;

public enum AssetCategoryType {
    FIXED, VARIABLE, REVENUE, PAYMENT
}
