package com.backend.frenv.domain.asset.entity;

import com.backend.frenv.domain.post.entity.PostImage;
import com.backend.frenv.domain.user.entity.User;
import com.backend.frenv.global.audit.AuditListener;
import com.backend.frenv.global.audit.Auditable;
import com.backend.frenv.global.audit.TimeEntity;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static javax.persistence.FetchType.*;
import static javax.persistence.GenerationType.*;
import static lombok.AccessLevel.*;

@Entity
@Getter
@NoArgsConstructor(access = PROTECTED)
@EntityListeners(AuditListener.class)
public class MoneyLog implements Auditable {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "money_log_id")
    private Long id;

    @Column(nullable = false)
    private LocalDate date;

    @Column(nullable = false)
    private String content;

    @OneToMany(mappedBy = "moneyLog", orphanRemoval = true)
    private List<PostImage> postImages = new ArrayList<>();

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Embedded
    private TimeEntity timeEntity;

    @Override
    public void setTimeEntity(TimeEntity timeEntity) {
        this.timeEntity = timeEntity;
    }

    @Builder
    public MoneyLog(Long id, LocalDate date, String content, List<PostImage> postImages, User user) {
        this.id = id;
        this.date = date;
        this.content = content;
        this.postImages = postImages;
        this.user = user;
    }

    public static MoneyLog createMoneyLog(LocalDate date, String content, User user) {
        return MoneyLog.builder()
                .date(date)
                .content(content)
                .user(user)
                .build();
    }

    public void updateMoneyLog(LocalDate date, String content) {
        this.date = date;
        this.content = content;
    }
}
