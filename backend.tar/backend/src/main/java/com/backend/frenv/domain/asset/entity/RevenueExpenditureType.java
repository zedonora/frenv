package com.backend.frenv.domain.asset.entity;

public enum RevenueExpenditureType {
    REVENUE, EXPENDITURE
}
