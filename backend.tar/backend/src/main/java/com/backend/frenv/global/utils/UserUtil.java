package com.backend.frenv.global.utils;

import com.backend.frenv.domain.user.entity.User;
import com.backend.frenv.domain.user.repository.UserRepository;
import com.backend.frenv.global.exception.CustomException;
import com.backend.frenv.global.exception.ErrorCode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class UserUtil {

    private final UserRepository userRepository;

    public User findCurrentUser() {
        User user = userRepository.findByUserId(SecurityUtil.getCurrentMemberId())
                .orElseThrow(() -> new CustomException(ErrorCode.NOT_FOUND_MEMBER));

        return user;
    }

}
