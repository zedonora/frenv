package com.backend.frenv.domain.post.repository.comment;

import com.backend.frenv.domain.post.entity.Comment;

import java.util.Optional;

public interface CommentCustomRepository {

    Optional<Comment> findWithPostAndMemberById(Long userId, Long commentId);

}
