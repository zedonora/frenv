export const FINANCIAL_CATEGORY = {
  REVENUE: '수익 카테고리',
  FIXED: '고정비 카테고리',
  VARIABLE: '변동비 카테고리',
  PAYMENT: '결제 카테고리',
};
