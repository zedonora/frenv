export const COMMUNITY_CATEGORY = {
  qna: '자산관리 QnA',
  share: '머니로그 & 통계 공유',
  free: '자유게시판',
};
